public class PrintHelper{
	public void print(String arg){
		System.out.println("PrintHelper printing.."+arg);
	}	
}