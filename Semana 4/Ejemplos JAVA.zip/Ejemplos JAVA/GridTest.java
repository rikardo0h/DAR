import java.lang.*;
import java.math.*;
import org.gridgain.grid.GridException;
import org.gridgain.grid.GridFactory;
import org.gridgain.grid.gridify.Gridify;

public class GridTest{

	public static void main(String args[]) throws GridException{
	
		GridFactory.start();
	
		try{	
			System.out.println("Grid test..");
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			GridFactory.stop(true);
		}
	}
	
}