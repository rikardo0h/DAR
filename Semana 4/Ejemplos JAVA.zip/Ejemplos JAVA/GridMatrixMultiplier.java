import java.lang.*;
import java.math.*;
import org.gridgain.grid.GridException;
import org.gridgain.grid.GridFactory;
import org.gridgain.grid.gridify.Gridify;

public class GridMatrixMultiplier{
	/**
	* Uncomment the print statements to capture the timings of the application.
	* As mentioned in the article for small applications, distributed computing takes longer time than run
	* as a local jvm due to network delays. Unless the size of the matrix increases to over 1000 you will see
	* any improvement in the timings.
	*/
	public static void main(String args[]) throws GridException{
		GridMatrixMultiplier mm= new GridMatrixMultiplier();
		GridFactory.start();
		//long t1 = System.currentTimeMillis();
		try{
			mm.runExample();
			//long t2 = System.currentTimeMillis();
			//System.out.println("Time taken :"+(t2-t1));
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			GridFactory.stop(true);
		}
	}
	/**
	* Define the size of the matric. Currently it multiplies a 10 X 5 matrix.
	*/
	public void runExample()
	{
		//populateMatrix1();
		int mat1[][] =  populateMatrix(10,5,1);
		int mat2[][] =  populateMatrix(5,10,1);

		printMatrix(mat1);
		System.out.println("X");
		printMatrix(mat2);
		System.out.println("=");
		printMatrix(multiplyMatricies(mat1, mat2));


	}
	/**
	* Populates the matrix.
	*/
	public int[][] populateMatrix(int rows, int cols, int starting_counter){
		int mat [][] = new int [rows][cols];
		for ( int i =0 ; i< rows; i++)
		{
			for(int j=0; j < cols; j++)
			{
				mat[i][j]= starting_counter++;
			}
		}
		return mat;
	}
	/**
	* Prints the matrix for visual representation to the screen
	*/
	public void printMatrix(int mat[][]){
		//System.out.println("Number of rows="+mat.length);
		//System.out.println("Number of columns="+mat[0].length);
		for ( int i =0; i < mat.length; i++)
		{
					System.out.print("|");
					for(int j=0; j < mat[0].length; j++)
					{
						System.out.print((j < mat[0].length -1) ? mat[i][j]+"," : mat[i][j]+"|");
					}
					System.out.println();
		}
	}
	/**
	 * Helper classes to identify the rows for multiplication
	 */
	public int [] getRowData(int mat[][], int row_num){
		int [] rowData = new int [mat[0].length];
		for(int i = 0; i < mat[0].length;  i++)
			rowData[i] = mat[row_num][i];
		return rowData;
	}

	public int[] getColData(int mat[][], int col_num){
		int [] colData = new int[mat.length];
		for(int i=0; i < mat.length ; i++)
			colData[i] = mat[i][col_num];
		return colData;

	}

	public int[][] multiplyMatricies(int mat1[][], int mat2[][]) {

		if(mat1[0].length != mat2.length){
			//throw new Exception("Number of rows of the first matrix must match the number of columns of second matrix.");
		}
		int result[][]= new int [mat1.length][mat2[0].length];
		//pull out row data of mat1
		int mat1_row_data [] =mat1[0];
		int mat2_col_data []= new int[mat2.length];
		for(int i=0; i < mat1.length; i++){
			mat1_row_data = getRowData(mat1, i);
			//printArray(mat1_row_data);
			for(int j=0; j < mat2[0].length; j++){
				mat2_col_data = getColData(mat2,j);
				//printArray(mat2_col_data);
				result[i][j] = compute(mat1_row_data, mat2_col_data);
			}
		}
		return result;
	}
	@Gridify
	public int compute(int arr1[], int arr2[]){

		int result =0;
		for(int i=0; i < arr1.length ; i++){
			result += arr1[i] * arr2[i];
		}
		System.out.println("Inside compute method..returning:"+result);
		return result;
	}
	public void printArray(int arr[]){
		System.out.print("[");
		for(int i=0; i < arr.length; i++)
			System.out.print((i < arr.length -1) ? arr[i]+"," : arr[i]+"]");
		System.out.println();
	}

}