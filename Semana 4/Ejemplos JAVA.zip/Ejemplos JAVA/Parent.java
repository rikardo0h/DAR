public class Parent{
	PrintHelper ph = new PrintHelper();
	public void print(){
		System.out.println("Inside parent..");
		ph.print("Print sth for Parent class..");
	}
}