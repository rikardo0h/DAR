import java.lang.*;
import java.math.*;
import org.gridgain.grid.GridException;
import org.gridgain.grid.GridFactory;
import org.gridgain.grid.gridify.Gridify;

public class GridHeirarchyTest{

	public static void main(String args[]) throws GridException{

		GridFactory.start();

		try{
			GridHeirarchyTest ght = new GridHeirarchyTest();
			ght.seeHowClassLoadingWorks();

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			GridFactory.stop(true);
		}
	}
	@Gridify
	public void seeHowClassLoadingWorks(){
		Child c = new Child();
		c.testPrint();
		//System.out.println("test heirarchy");
	}

}