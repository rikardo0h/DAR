public class Child extends Parent{
	
	public void testPrint(){
		System.out.println("Inside Child calling parent..");
		print();
	}
}