﻿using System.Net.NetworkInformation;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System;
using System.Net;
using System.Text;

static class Module1
{
    //sdsd

    private static List<Ping> pingers = new List<Ping>();
    private static int instances = 0;
    private static object @lock = new object();
    private static int result = 0;
    private static int timeOut = 250;
    private static int ttl = 5;
    public static void Main(string[] args)
    {
        string baseIP = "172.20.10.";
        //string baseIP = args[0];
        Console.WriteLine("Ping en 255 {0}*", baseIP);
        crearPing(255);



        PingOptions po = new PingOptions(ttl, true);
        System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
        byte[] data = enc.GetBytes("abababababababababababababababab");

        SpinWait wait = new SpinWait();
        int cnt = 1;

        Stopwatch watch = Stopwatch.StartNew();

        foreach (Ping p in pingers)
        {
            lock (@lock)
            {
                instances += 1;
            }

            p.SendAsync(string.Concat(baseIP, cnt.ToString()), timeOut, data, po);
            cnt += 1;
        }

        while (instances > 0)
        {
            wait.SpinOnce();
        }

        watch.Stop();
        eliminarPing();
        Console.WriteLine("Fin  {0}. Encontradas {1} direcciones en uso.", watch.Elapsed.ToString(), result);
        Console.ReadKey();

    }

    public static void ping_recibido(object s, PingCompletedEventArgs e)
    {
        lock (@lock){
            instances -= 1;
        }

        if (e.Reply.Status == IPStatus.Success){
            Console.WriteLine(string.Concat(" IP: ", e.Reply.Address.ToString()) + " Mac:" + obtenerMac(e.Reply.Address.ToString()));
            result += 1;
        }
    }


    private static void crearPing(int cnt)
    {
        for (int i = 1; i <= cnt; i++)
        {
            Ping p = new Ping();
            p.PingCompleted += ping_recibido;
            pingers.Add(p);
        }
    }

    private static void eliminarPing()
    {
        foreach (Ping p in pingers){
            p.PingCompleted -= ping_recibido;
            p.Dispose();
        }
        pingers.Clear();

    }
    private static string obtenerMac(string ipAddress)
    {
        string macAddress = string.Empty;
        System.Diagnostics.Process pProcess = new System.Diagnostics.Process();
        pProcess.StartInfo.FileName = "arp";
        pProcess.StartInfo.Arguments = "-a " + ipAddress;
        pProcess.StartInfo.UseShellExecute = false;
        pProcess.StartInfo.RedirectStandardOutput = true;
        pProcess.StartInfo.CreateNoWindow = true;
        pProcess.Start();
        string strOutput = pProcess.StandardOutput.ReadToEnd();
        string[] substrings = strOutput.Split('-');
        if (substrings.Length >= 8)
        {
            macAddress = substrings[3].Substring(Math.Max(0, substrings[3].Length - 2))
                     + "-" + substrings[4] + "-" + substrings[5] + "-" + substrings[6]
                     + "-" + substrings[7] + "-"
                     + substrings[8].Substring(0, 2);
            return macAddress;
        }
        else
        {
            return "not found";
        }
    }




}


