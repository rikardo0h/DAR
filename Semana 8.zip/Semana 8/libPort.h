#ifndef _LIBPORT_H_
#define _LIBPORT_H_

/*Las lineas anteriores siempre van y se nombran segun el nombre que se le
 haya dado al archivo pero en mayúsculas*/

extern int isFile();
extern int readPorts(char *argv[]);

#endif